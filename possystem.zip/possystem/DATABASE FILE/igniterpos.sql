-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
-- Host: 127.0.0.1
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `igniterpos`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblGoods`
--

CREATE TABLE `tblGoods` (
  `IdGoods` char(7) NOT NULL,
  `NameGoods` varchar(255) NOT NULL,
  `Stock` int(11) NOT NULL,
  `UnitId` int(11) NOT NULL,
  `TypeId` int(11) NOT NULL,
  `Price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `tblGoods`
--

INSERT INTO `tblGoods` (`IdGoods`, `NameGoods`, `Stock`, `UnitId`, `TypeId`, `Price`) VALUES
('CA0000', 'WEN Benchtop Drill Press', 101, 3, 8, 177),
('CA0001', 'Hermes Hardware Magnetic Drilling Machine', 159, 3, 8, 296),
('CA0002', 'CubiCubi Study Computer Desk', 89, 3, 13, 97),
('CA0003', 'Samsung 870 EVO 1TB SATA III Internal SSD', 219, 3, 14, 102),
('CA0004', 'Logitech BRIO Ultra HD Webcam', 73, 2, 9, 224),
('CA0005', 'MR.SIGA Microfiber Cleaning Cloth', 552, 2, 10, 11),
('CA0006', 'Amazon Basics LR44 Alkaline Button Coin Cell Battery', 1105, 2, 12, 4),
('CA0007', 'Kaisi 136 in 1 Electronics Repair Tool Kit', 141, 2, 11, 47),
('CA0008', 'Logitech MK270 Wireless Keyboard', 242, 3, 9, 31),
('CA0009', 'Duracell CopperTop Alkaline Batteries', 823, 2, 12, 16),
('CA0010', 'SAMSUNG T5 1TB External SSD', 116, 3, 14, 105),
('CA0011', 'Bolanburg Console Table', 9, 3, 13, 575),
('CA0012', 'Air Fryer Max XL Digital Hot Oven Cooker', 108, 3, 15, 119);

-- --------------------------------------------------------

--
-- Table structure for table `tblGoodsOutgoing`
--

CREATE TABLE `tblGoodsOutgoing` (
  `IdGoodsOutgoing` char(16) NOT NULL,
  `UserId` int(11) NOT NULL,
  `NameRecipient` char(50) NOT NULL,
  `Address` text NOT NULL,
  `DateOutgoing` date NOT NULL,
  `Discount` double(11,0) DEFAULT '0',
  `TotalNominal` int(11) NOT NULL,
  `GrandTotal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `tblGoodsOutgoing`
--

INSERT INTO `tblGoodsOutgoing` (`IdGoodsOutgoing`, `UserId`, `NameRecipient`, `Address`, `DateOutgoing`, `Discount`, `TotalNominal`, `GrandTotal`) VALUES
('S2106030000', 1, 'Colin Stuart', '2445 Allace Avenue', '2021-06-03', 3, 407, 404),
('S2106030001', 1, 'Naomi Valencia', '1560  Lonely Oak Drive', '2021-06-03', 4, 837, 833),
('S2106030002', 1, 'Christine', '71 Bridge Road', '2021-06-03', 1, 1568, 1567),
('S2106030003', 1, 'Wilson Smith', '714 Bleck Street', '2021-06-03', 3, 544, 541),
('S2106030004', 1, 'Stephen McCaul', '714 Alv Lane', '2021-06-03', 2, 1792, 1790),
('S2106030005', 1, 'Christopher Coates', '2471 Strother Street', '2021-06-03', 15, 8984, 8969),
('S2106030006', 1, 'Michelle Jacobson', '2270 Skips Lane', '2021-06-03', 15, 2023, 2008);

-- --------------------------------------------------------

--
-- Table structure for table `tblGoodsOutgoingCopy1`
--

CREATE TABLE `tblGoodsOutgoingCopy1` (
  `IdGoodsOutgoing` char(16) NOT NULL,
  `UserId` int(11) NOT NULL,
  `GoodsId` char(7) NOT NULL,
  `NameRecipient` char(50) NOT NULL,
  `Address` text NOT NULL,
  `AmountOutgoing` int(11) NOT NULL,
  `DateOutgoing` date NOT NULL,
  `TotalNominal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Triggers `tblGoodsOutgoingCopy1`
--
DELIMITER $$
CREATE TRIGGER `update_Stock_keluar_copy1` BEFORE INSERT ON `tblGoodsOutgoingCopy1` FOR EACH ROW UPDATE `tblGoods` SET `tblGoods`.`Stock` = `tblGoods`.`Stock` - NEW.AmountOutgoing WHERE `tblGoods`.`IdGoods` = NEW.GoodsId
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tblGoodsOutgoingDtl`
--

CREATE TABLE `tblGoodsOutgoingDtl` (
  `IdDetails` int(11) NOT NULL,
  `IdGoodsOutgoing` char(16) NOT NULL,
  `GoodsId` char(7) NOT NULL,
  `Price` int(11) NOT NULL,
  `AmountOutgoing` int(1) NOT NULL,
  `TotalNominalDtl` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `tblGoodsOutgoingDtl`
--

INSERT INTO `tblGoodsOutgoingDtl` (`IdDetails`, `IdGoodsOutgoing`, `GoodsId`, `Price`, `AmountOutgoing`, `TotalNominalDtl`) VALUES
(20, 'S2106030000', 'CA0005', 11, 37, 407),
(21, 'S2106030001', 'CA0008', 31, 27, 837),
(22, 'S2106030002', 'CA0004', 224, 7, 1568),
(23, 'S2106030003', 'CA0009', 16, 29, 464),
(24, 'S2106030003', 'CA0006', 4, 20, 80),
(25, 'S2106030004', 'CA0004', 224, 8, 1792),
(26, 'S2106030005', 'CA0010', 105, 56, 5880),
(27, 'S2106030005', 'CA0002', 97, 32, 3104),
(28, 'S2106030006', 'CA0012', 119, 17, 2023);

--
-- Triggers `tblGoodsOutgoingDtl`
--
DELIMITER $$
CREATE TRIGGER `delete_Stock_keluar` AFTER DELETE ON `tblGoodsOutgoingDtl` FOR EACH ROW UPDATE `tblGoods` SET `tblGoods`.`Stock` = `tblGoods`.`Stock` + OLD.AmountOutgoing WHERE `tblGoods`.`IdGoods` = OLD.GoodsId
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_Stock_keluar` BEFORE INSERT ON `tblGoodsOutgoingDtl` FOR EACH ROW UPDATE `tblGoods` SET `tblGoods`.`Stock` = `tblGoods`.`Stock` - NEW.AmountOutgoing WHERE `tblGoods`.`IdGoods` = NEW.GoodsId
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tblGoodsIncoming`
--

CREATE TABLE `tblGoodsIncoming` (
  `IdGoodsIncoming` char(16) NOT NULL,
  `tblSupplierId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `GoodsId` char(7) NOT NULL,
  `AmountIncoming` int(11) NOT NULL,
  `DateIncoming` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `tblGoodsIncoming`
--

INSERT INTO `tblGoodsIncoming` (`IdGoodsIncoming`, `tblSupplierId`, `UserId`, `GoodsId`, `AmountIncoming`, `DateIncoming`) VALUES
('I2106030000', 4, 1, 'CA0000', 78, '2020-12-17'),
('I2106030001', 4, 1, 'CA0001', 111, '2020-12-29'),
('I2106030002', 7, 1, 'CA0002', 181, '2020-12-30'),
('I2106030003', 5, 1, 'CA0003', 219, '2020-12-31'),
('I2106030004', 5, 1, 'CA0004', 368, '2020-12-31'),
('I2106030005', 5, 1, 'CA0008', 269, '2020-12-31'),
('I2106030006', 6, 1, 'CA0005', 589, '2021-01-04'),
('I2106030007', 5, 1, 'CA0006', 1125, '2021-01-04'),
('I2106030008', 7, 1, 'CA0002', 121, '2021-03-10'),
('I2106030009', 4, 1, 'CA0007', 141, '2021-01-19'),
('I2106030010', 4, 1, 'CA0000', 23, '2021-06-01'),
('I2106030011', 5, 1, 'CA0010', 172, '2021-06-03'),
('I2106030012', 9, 1, 'CA0009', 852, '2021-06-03'),
('I2106030013', 7, 1, 'CA0011', 112, '2021-06-03'),
('I2106030014', 10, 1, 'CA0012', 167, '2021-06-03'),
('I2106030015', 4, 1, 'CA0001', 152, '2021-06-03'),
('I2106030016', 10, 1, 'CA0012', 125, '2021-06-03'),
('I2106030017', 5, 1, 'CA0004', 68, '2021-06-03');

--
-- Triggers `tblGoodsIncoming`
--
DELIMITER $$
CREATE TRIGGER `update_Stock_masuk` BEFORE INSERT ON `tblGoodsIncoming` FOR EACH ROW UPDATE `tblGoods` SET `tblGoods`.`Stock` = `tblGoods`.`Stock` + NEW.AmountIncoming WHERE `tblGoods`.`IdGoods` = NEW.GoodsId
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tblType`
--

CREATE TABLE `tblType` (
  `IdType` int(11) NOT NULL,
  `NameType` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `tblType`
--

INSERT INTO `tblType` (`IdType`, `NameType`) VALUES
(8, 'Machinery'),
(9, 'Computer Accessories'),
(10, 'Cleaning Supplies'),
(11, 'Repair Tools'),
(12, 'Batteries'),
(13, 'Furniture'),
(14, 'Computer Components'),
(15, 'Home & Kitchen');

-- --------------------------------------------------------

--
-- Table structure for table `tblUnit`
--

CREATE TABLE `tblUnit` (
  `IdUnit` int(11) NOT NULL,
  `NameUnit` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `tblUnit`
--

INSERT INTO `tblUnit` (`IdUnit`, `NameUnit`) VALUES
(2, 'Pack'),
(3, 'Piece'),
(5, 'Unit'),
(6, 'KG'),
(7, 'Meter');

-- --------------------------------------------------------

--
-- Table structure for table `tblSupplier`
--

CREATE TABLE `tblSupplier` (
  `IdSupplier` int(11) NOT NULL,
  `NameSupplier` varchar(50) NOT NULL,
  `NoTelp` varchar(15) NOT NULL,
  `Address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `tblSupplier`
--

INSERT INTO `tblSupplier` (`IdSupplier`, `NameSupplier`, `NoTelp`, `Address`) VALUES
(4, 'Unibe Limited', '2450003670', '1568  Wood Duck Drive'),
(5, 'SISSE Partners', '0250124570', '4328  Bassell Avenue'),
(6, 'Membozza', '0843696960', '2303  Poplar Lane'),
(7, 'GIGGY Furniture', '0366967856', '143  Huntly Street'),
(8, 'Morise Goods', '0147545458', '3502  Lunetta Street'),
(9, 'Wisdom tblSuppliers', '0147850002', '1560  Lonely Oak Drive'),
(10, 'Supplify Ware', '0145457850', '775 Oak Drive');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `IdUser` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `NoTelp` varchar(15) NOT NULL,
  `role` enum('gudang','admin') NOT NULL,
  `password` varchar(255) NOT NULL,
  `CreatedAt` int(11) NOT NULL,
  `Photo` text NOT NULL,
  `IsActive` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`IdUser`, `Name`, `username`, `email`, `NoTelp`, `role`, `password`, `CreatedAt`, `Photo`, `IsActive`) VALUES
(1, 'Administrator', 'admin', 'admin@admin.com', '025123456789', 'admin', '$2y$10$7rLSvRVyTQORapkDOqmkhetjF6H9lJHngr4hJMSM2lHObJbW5EQh6', 1568689561, 'admin-icn.png', 1),
(7, 'Will Williams', 'williams', 'williams@gmail.com', '7401000010', 'gudang', '$2y$10$5es8WhFQj8xCmrhDtH86Fu71j97og9f8aR4T22soa7716kAusmaeK', 1568691611, 'user.png', 1),
(15, 'Liam Moore', 'liamoore', 'liamoore@gmail.com', '7474754520', 'gudang', '$2y$10$1Yxca5aH4q8XZpMZm0kE..IZk1L/tqDYS0JkAr.mWJ7BeNmRzYdCq', 1622746060, 'user.png', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblGoods`
--
ALTER TABLE `tblGoods`
  ADD PRIMARY KEY (`IdGoods`) USING BTREE,
  ADD KEY `UnitId` (`UnitId`) USING BTREE,
  ADD KEY `kategori_id` (`TypeId`) USING BTREE;

--
-- Indexes for table `tblGoodsOutgoing`
--
ALTER TABLE `tblGoodsOutgoing`
  ADD PRIMARY KEY (`IdGoodsOutgoing`) USING BTREE,
  ADD KEY `IdUser` (`UserId`) USING BTREE;

--
-- Indexes for table `tblGoodsOutgoingCopy1`
--
ALTER TABLE `tblGoodsOutgoingCopy1`
  ADD PRIMARY KEY (`IdGoodsOutgoing`) USING BTREE,
  ADD KEY `IdUser` (`UserId`) USING BTREE,
  ADD KEY `GoodsId` (`GoodsId`) USING BTREE;

--
-- Indexes for table `tblGoodsOutgoingDtl`
--
ALTER TABLE `tblGoodsOutgoingDtl`
  ADD PRIMARY KEY (`IdDetails`) USING BTREE,
  ADD KEY `tblGoodsOutgoingDtl_ibfk_1` (`IdGoodsOutgoing`) USING BTREE;

--
-- Indexes for table `tblGoodsIncoming`
--
ALTER TABLE `tblGoodsIncoming`
  ADD PRIMARY KEY (`IdGoodsIncoming`) USING BTREE,
  ADD KEY `IdUser` (`UserId`) USING BTREE,
  ADD KEY `tblSupplierId` (`tblSupplierId`) USING BTREE,
  ADD KEY `GoodsId` (`GoodsId`) USING BTREE;

--
-- Indexes for table `tblType`
--
ALTER TABLE `tblType`
  ADD PRIMARY KEY (`IdType`) USING BTREE;

--
-- Indexes for table `tblUnit`
--
ALTER TABLE `tblUnit`
  ADD PRIMARY KEY (`IdUnit`) USING BTREE;

--
-- Indexes for table `tblSupplier`
--
ALTER TABLE `tblSupplier`
  ADD PRIMARY KEY (`IdSupplier`) USING BTREE;

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`IdUser`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblGoodsOutgoingDtl`
--
ALTER TABLE `tblGoodsOutgoingDtl`
  MODIFY `IdDetails` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `tblType`
--
ALTER TABLE `tblType`
  MODIFY `IdType` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `tblUnit`
--
ALTER TABLE `tblUnit`
  MODIFY `IdUnit` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tblSupplier`
--
ALTER TABLE `tblSupplier`
  MODIFY `IdSupplier` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `IdUser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblGoods`
--
ALTER TABLE `tblGoods`
  ADD CONSTRAINT `tblGoods_ibfk_1` FOREIGN KEY (`UnitId`) REFERENCES `tblUnit` (`IdUnit`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tblGoods_ibfk_2` FOREIGN KEY (`TypeId`) REFERENCES `tblType` (`IdType`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblGoodsOutgoing`
--
ALTER TABLE `tblGoodsOutgoing`
  ADD CONSTRAINT `tblGoodsOutgoing_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `user` (`IdUser`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblGoodsOutgoingCopy1`
--
ALTER TABLE `tblGoodsOutgoingCopy1`
  ADD CONSTRAINT `tblGoodsOutgoingCopy1_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `user` (`IdUser`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tblGoodsOutgoingCopy1_ibfk_2` FOREIGN KEY (`GoodsId`) REFERENCES `tblGoods` (`IdGoods`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblGoodsOutgoingDtl`
--
ALTER TABLE `tblGoodsOutgoingDtl`
  ADD CONSTRAINT `tblGoodsOutgoingDtl_ibfk_1` FOREIGN KEY (`IdGoodsOutgoing`) REFERENCES `tblGoodsOutgoing` (`IdGoodsOutgoing`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblGoodsIncoming`
--
ALTER TABLE `tblGoodsIncoming`
  ADD CONSTRAINT `tblGoodsIncoming_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `user` (`IdUser`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tblGoodsIncoming_ibfk_2` FOREIGN KEY (`tblSupplierId`) REFERENCES `tblSupplier` (`IdSupplier`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tblGoodsIncoming_ibfk_3` FOREIGN KEY (`GoodsId`) REFERENCES `tblGoods` (`IdGoods`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
