<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin_model extends CI_Model
{
    public function get($table, $data = null, $where = null)
    {
        if ($data != null) {
            return $this->db->get_where($table, $data)->row_array();
        } else {
            return $this->db->get_where($table, $where)->result_array();
        }
    }

    public function update($table, $pk, $id, $data)
    {
        $this->db->where($pk, $id);
        return $this->db->update($table, $data);
    }

    public function insert($table, $data, $batch = false)
    {
        return $batch ? $this->db->insert_batch($table, $data) : $this->db->insert($table, $data);
    }

    public function delete($table, $pk, $id)
    {
        return $this->db->delete($table, [$pk => $id]);
    }

    public function update_Stock($IdGoods, $data)
    {
        $this->db->where('IdGoods', $IdGoods);
        $this->db->update('tblGoods', $data);
    }

    public function getUsers($id)
    {
        /**
         * ID disini adalah untuk data yang tidak ingin ditampilkan. 
         * Maksud saya disini adalah 
         * tidak ingin menampilkan data user yang digunakan, 
         * pada managemen data user
         */
        $this->db->where('IdUser !=', $id);
        return $this->db->get('user')->result_array();
    }

    public function gettblGoods()
    {
        $this->db->join('tblType j', 'b.TypeId = j.IdType');
        $this->db->join('tblUnit s', 'b.UnitId = s.IdUnit');
        $this->db->order_by('IdGoods');
        return $this->db->get('tblGoods b')->result_array();
    }

    public function gettblGoodsIncoming($limit = null, $IdGoods = null, $range = null)
    {
        $this->db->select('*');
        $this->db->join('user u', 'bm.UserId = u.IdUser');
        $this->db->join('tblSupplier sp', 'bm.tblSupplierId = sp.IdSupplier');
        $this->db->join('tblGoods b', 'bm.GoodsId = b.IdGoods');
        $this->db->join('tblUnit s', 'b.UnitId = s.IdUnit');
        if ($limit != null) {
            $this->db->limit($limit);
        }

        if ($IdGoods != null) {
            $this->db->where('IdGoods', $IdGoods);
        }

        if ($range != null) {
            $this->db->where('DateIncoming' . ' >=', $range['Start']);
            $this->db->where('DateIncoming' . ' <=', $range['End']);
        }

        $this->db->order_by('IdGoodsIncoming', 'DESC');
        return $this->db->get('tblGoodsIncoming bm')->result_array();
    }

    public function gettblGoodsOutgoingDashboard($limit = null, $range = null)
    {
        $this->db->select('*');
        $this->db->join('tblGoodsOutgoing bk', 'bk.IdGoodsOutgoing = bkd.IdGoodsOutgoing');
        $this->db->join('user u', 'bk.UserId = u.IdUser');
        $this->db->join('tblGoods b', 'bkd.GoodsId = b.IdGoods');
        $this->db->join('tblUnit s', 'b.UnitId = s.IdUnit');
        if ($limit != null) {
            $this->db->limit($limit);
        }
        // if ($IdGoods != null) {
        //     $this->db->where('IdGoods', $IdGoods);
        // }
        if ($range != null) {
            $this->db->where('DateOutgoing' . ' >=', $range['Start']);
            $this->db->where('DateOutgoing' . ' <=', $range['End']);
        }
        $this->db->order_by('bkd.IdDetails', 'DESC');
        return $this->db->get('tblGoodsOutgoingDtl bkd')->result_array();
    }

    public function gettblGoodsOutgoing($limit = null, $range = null)
    {
        $this->db->select('*');
        $this->db->join('tblGoodsOutgoing bk', 'bk.IdGoodsOutgoing = bkd.IdGoodsOutgoing');
        // $this->db->join('user u', 'bk.UserId = u.IdUser');
        $this->db->join('tblGoods b', 'bkd.GoodsId = b.IdGoods');
        $this->db->join('tblUnit s', 'b.UnitId = s.IdUnit');
        if ($limit != null) {
            $this->db->limit($limit);
        }
        // if ($IdGoods != null) {
        //     $this->db->where('IdGoods', $IdGoods);
        // }
        if ($range != null) {
            $this->db->where('DateOutgoing' . ' >=', $range['Start']);
            $this->db->where('DateOutgoing' . ' <=', $range['End']);
        }
        // $this->db->group_by('bk.IdGoodsOutgoing', 'DESC');
        $this->db->order_by('bk.IdGoodsOutgoing', 'DESC');
        return $this->db->get('tblGoodsOutgoingDtl bkd')->result_array();
    }

    public function getIDtblGoodsOutgoing($IdGoodsOutgoing)
    {
        $this->db->select('*');
        $this->db->join('user u', 'bk.UserId = u.IdUser');
        $this->db->join('tblGoods b', 'bk.GoodsId = b.IdGoods');
        $this->db->join('tblType j', 'b.TypeId = j.IdType');
        $this->db->join('tblUnit s', 'b.UnitId = s.IdUnit');
        $this->db->where('bk.IdGoodsOutgoing', $IdGoodsOutgoing);
        $this->db->order_by('IdGoodsOutgoing', 'DESC');
        return $this->db->get('tblGoodsOutgoing bk');
    }

    public function getIDtblGoodsOutgoing2($IdGoodsOutgoing)
    {
        $this->db->select('*');  
        $this->db->join('tblGoodsOutgoing bk', 'bk.IdGoodsOutgoing = bkd.IdGoodsOutgoing');
        $this->db->join('user u', 'bk.UserId = u.IdUser');
        $this->db->join('tblGoods b', 'bkd.GoodsId = b.IdGoods');
        $this->db->join('tblType j', 'b.TypeId = j.IdType');
        $this->db->join('tblUnit s', 'b.UnitId = s.IdUnit');
        $this->db->where('bk.IdGoodsOutgoing', $IdGoodsOutgoing);
        // $this->db->order_by('IdGoodsOutgoing bk', 'DESC');
        return $this->db->get('tblGoodsOutgoingDtl bkd');
    }

    public function findIDtblGoodsOutgoing($id)
    {
        $query = $this->db->where('IdGoodsOutgoing',$id)
       // ->limit(100)
        ->get('tblGoodsOutgoing');
        if($query->num_rows() > 0){
            return $query->row_array();
            //return $query;
        }else{
            return array();
            //return $query;
        }
    }

    public function simpan_cart($IdGoodsOutgoing){
        foreach ($this->cart->contents() as $item) {
            $data=array(
                'IdGoodsOutgoing'  =>  $IdGoodsOutgoing,
                'GoodsId'       =>  $item['id'],
                'Price'           =>  $item['amount'],
                'AmountOutgoing'   =>  $item['qty'],
                'TotalNominalDtl'   =>  $item['subtotal']
            );
            $this->db->insert('tblGoodsOutgoingDtl',$data);
            // $this->db->query("update tbl_tblGoods set tblGoods_Stock=tblGoods_Stock-'$item[qty]' where GoodsId='$item[id]'");
        }
        return true;
    }

    public function get_tblGoods($IdGoods){
        $query=$this->db->query("SELECT * FROM tblGoods where IdGoods='$IdGoods'");
        return $query;
    }

    public function getMax($table, $field, $kode = null)
    {
        $this->db->select_max($field);
        if ($kode != null) {
            $this->db->like($field, $kode, 'after');
        }
        return $this->db->get($table)->row_array()[$field];
    }

    public function count($table)
    {
        return $this->db->count_all($table);
    }

    public function sum($table, $field)
    {
        $this->db->select_sum($field);
        return $this->db->get($table)->row_array()[$field];
    }

    public function min($table, $field, $min)
    {
        $field = $field . ' <=';
        $this->db->where($field, $min);
        return $this->db->get($table)->result_array();
    }

    public function charttblGoodsIncoming($bulan)
    {
        $like = 'I' . date('y') . $bulan;
        $this->db->like('IdGoodsIncoming', $like, 'after');
        return count($this->db->get('tblGoodsIncoming')->result_array());
    }

    public function charttblGoodsOutgoing($bulan)
    {
        $like = 'S' . date('y') . $bulan;
        $this->db->like('IdGoodsOutgoing', $like, 'after');
        return count($this->db->get('tblGoodsOutgoingDtl')->result_array());
    }

    public function report($table, $Start, $End)
    {
        $tgl = $table == 'tblGoodsIncoming' ? 'DateIncoming' : 'DateOutgoing';
        $this->db->where($tgl . ' >=', $Start);
        $this->db->where($tgl . ' <=', $End);
        return $this->db->get($table)->result_array();
    }

    public function checkStock($id)
    {
        $this->db->join('tblUnit s', 'b.UnitId=s.IdUnit');
        return $this->db->get_where('tblGoods b', ['IdGoods' => $id])->row_array();
    }
}
