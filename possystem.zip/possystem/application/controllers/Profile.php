<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Profile extends CI_Controller
{
    protected $user;

    public function __construct()
    {
        parent::__construct();
        check_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');

        $userId = $this->session->userdata('login_session')['user'];
        $this->user = $this->admin->get('user', ['IdUser' => $userId]);
    }

    public function index()
    {
        $data['title'] = "Profile";
        $data['user'] = $this->user;
        $this->template->load('templates/dashboard', 'profile/user', $data);
    }

    private function _validation()
    {
        $db = $this->admin->get('user', ['IdUser' => $this->input->post('IdUser', true)]);
        $username = $this->input->post('username', true);
        $email = $this->input->post('email', true);

        $uniq_username = $db['username'] == $username ? '' : '|is_unique[user.username]';
        $uniq_email = $db['email'] == $email ? '' : '|is_unique[user.email]';

        $this->form_validation->set_rules('username', 'Username', 'required|trim|alpha_numeric' . $uniq_username);
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email' . $uniq_email);
        $this->form_validation->set_rules('Name', 'Name', 'required|trim');
        $this->form_validation->set_rules('NoTelp', 'Nomor Telepon', 'required|trim|numeric');
    }

    private function _config()
    {
        $config['upload_path']      = "./assets/img/avatar";
        $config['allowed_types']    = 'gif|jpg|jpeg|png';
        $config['encrypt_name']     = TRUE;
        $config['max_size']         = '2048';

        $this->load->library('upload', $config);
    }

    public function setting()
    {
        $this->_validation();
        $this->_config();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Profile";
            $data['user'] = $this->user;
            $this->template->load('templates/dashboard', 'profile/setting', $data);
        } else {
            $input = $this->input->post(null, true);
            if (empty($_FILES['Photo']['name'])) {
                $insert = $this->admin->update('user', 'IdUser', $input['IdUser'], $input);
                if ($insert) {
                    setMessage('Changes Saved');
                } else {
                    setMessage('Changes NOT SAVED.');
                }
                redirect('profile/setting');
            } else {
                if ($this->upload->do_upload('Photo') == false) {
                    echo $this->upload->display_errors();
                    die;
                } else {
                    if (userdata('Photo') != 'user.png') {
                        $old_image = FCPATH . 'assets/img/avatar/' . userdata('Photo');
                        if (!unlink($old_image)) {
                            setMessage('gagal hapus Photo lama.');
                            redirect('profile/setting');
                        }
                    }

                    $input['Photo'] = $this->upload->data('file_name');
                    $update = $this->admin->update('user', 'IdUser', $input['IdUser'], $input);
                    if ($update) {
                        setMessage('Changes has been made');
                    } else {
                        setMessage('Failed to save your changes');
                    }
                    redirect('profile/setting');
                }
            }
        }
    }

    public function updatepassword()
    {
        $this->form_validation->set_rules('password_lama', 'Password Lama', 'required|trim');
        $this->form_validation->set_rules('password_baru', 'Password Baru', 'required|trim|min_length[3]|differs[password_lama]');
        $this->form_validation->set_rules('konfirmasi_password', 'Konfirmasi Password', 'matches[password_baru]');

        if ($this->form_validation->run() == false) {
            $data['title'] = "Change Password";
            $this->template->load('templates/dashboard', 'profile/updatepassword', $data);
        } else {
            $input = $this->input->post(null, true);
            if (password_verify($input['password_lama'], userdata('password'))) {
                $new_pass = ['password' => password_hash($input['password_baru'], PASSWORD_DEFAULT)];
                $query = $this->admin->update('user', 'IdUser', userdata('IdUser'), $new_pass);

                if ($query) {
                    setMessage('Your password has been updated!');
                } else {
                    setMessage('Hahaha, Something went wrong', false);
                }
            } else {
                setMessage('Looks like something is wrong, Your current password is totally wrong!!', false);
            }
            redirect('profile/updatepassword');
        }
    }
}
