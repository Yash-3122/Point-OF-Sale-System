<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Report extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        check_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $this->form_validation->set_rules('Transaction', 'Transaction', 'required|in_list[tblGoodsIncoming,tblGoodsOutgoing,tblGoodsOutgoing_nominal]');
        $this->form_validation->set_rules('Date', 'Periode Date', 'required');

        if ($this->form_validation->run() == false) {
            $data['title'] = "Transaction Report";
            $this->template->load('templates/dashboard', 'report/form', $data);
        } else {
            $input = $this->input->post(null, true);
            $table = $input['Transaction'];
            $Date = $input['Date'];
            $pecah = explode(' - ', $Date);
            $Start = date('Y-m-d', strtotime($pecah[0]));
            $End = date('Y-m-d', strtotime(end($pecah)));

            $query = '';
            if ($table == 'tblGoodsIncoming') {
                $query = $this->admin->gettblGoodsIncoming(null, null, ['Start' => $Start, 'End' => $End]);
            } elseif ($table == 'tblGoodsOutgoing') {
                $query = $this->admin->gettblGoodsOutgoing(null, null, ['Start' => $Start, 'End' => $End]);
            } else {
                $query = $this->admin->gettblGoodsOutgoing(null, null, ['Start' => $Start, 'End' => $End]);
            }

            $this->_cetak($query, $table, $Date);
        }
    }

    private function _cetak($data, $table_, $Date)
    {
        $this->load->library('CustomPDF');
        $table = $table_ == 'tblGoodsIncoming' ? 'Incoming Goods' : 'Out Goods';

        $pdf = new FPDF();
        $pdf->AddPage('P', 'A4');
        $pdf->SetFont('Times', 'B', 16);
        $pdf->Cell(190, 7, 'Report ' . $table, 0, 1, 'C');
        $pdf->SetFont('Times', '', 10);
        $pdf->Cell(190, 4, 'Date : ' . $Date, 0, 1, 'C');
        $pdf->Ln(10);

        $pdf->SetFont('Arial', 'B', 9);

        if ($table_ == 'tblGoodsIncoming') :
            $pdf->Cell(10, 7, 'No.', 1, 0, 'C');
            $pdf->Cell(25, 7, 'Entry Date', 1, 0, 'C');
            $pdf->Cell(35, 7, 'ID', 1, 0, 'C');
            $pdf->Cell(55, 7, 'Goods Name', 1, 0, 'C');
            $pdf->Cell(40, 7, 'tblSupplier', 1, 0, 'C');
            $pdf->Cell(30, 7, 'Number of Entries', 1, 0, 'C');
            $pdf->Ln();

            $no = 1;
            foreach ($data as $d) {
                $pdf->SetFont('Arial', '', 10);
                $pdf->Cell(10, 7, $no++ . '.', 1, 0, 'C');
                $pdf->Cell(25, 7, date('d-m-Y', strtotime($d['DateIncoming'])), 1, 0, 'C');
                $pdf->Cell(35, 7, $d['IdGoodsIncoming'], 1, 0, 'C');
                $pdf->Cell(55, 7, $d['NameGoods'], 1, 0, 'L');
                $pdf->Cell(40, 7, $d['NameSupplier'], 1, 0, 'L');
                $pdf->Cell(30, 7, $d['AmountIncoming'] . ' ' . $d['NameUnit'], 1, 0, 'C');
                $pdf->Ln();
            } 

        elseif ($table_ == 'tblGoodsOutgoing') :
            $pdf->Cell(10, 7, '#', 1, 0, 'C');
            $pdf->Cell(18, 7, 'Out-Date', 1, 0, 'C');
            $pdf->Cell(30, 7, 'ID', 1, 0, 'C');
            $pdf->Cell(55, 7, 'Goods Name', 1, 0, 'C');
            $pdf->Cell(25, 7, 'Receiver', 1, 0, 'C');
            $pdf->Cell(35, 7, 'Address', 1, 0, 'C');
            $pdf->Cell(18, 7, 'Total Qty', 1, 0, 'C');
            // $pdf->Cell(25, 7, 'Total', 1, 0, 'C');

            $pdf->Ln();

            $no = 1;
            $grandTotal = 0;
            foreach ($data as $d) {
                $grandTotal += $d['GrandTotal'];
                $pdf->SetFont('Arial', '', 8);
                $pdf->Cell(10, 7, $no++ . '.', 1, 0, 'C');
                $pdf->Cell(18, 7, date('d-m-Y', strtotime($d['DateOutgoing'])), 1, 0, 'C');
                $pdf->Cell(30, 7, $d['IdGoodsOutgoing'], 1, 0, 'C');
                $pdf->Cell(55, 7, $d['NameGoods'], 1, 0, 'L');
                $pdf->Cell(25, 7, $d['NameRecipient'], 1, 0, 'L');
                $pdf->Cell(35, 7, $d['Address'], 1, 0, 'L');
                $pdf->Cell(18, 7, $d['AmountOutgoing'] . ' ' . $d['NameUnit'], 1, 0, 'C');
                // $pdf->Cell(25, 7, '$'.number_format($d['GrandTotal'],0,',','.'), 1, 0, 'L');

                $pdf->Ln();
                
            } 
        else :
            $pdf->Cell(7, 7, '#', 1, 0, 'C');
            $pdf->Cell(16, 7, 'Out-Date', 1, 0, 'C');
            $pdf->Cell(27, 7, 'ID', 1, 0, 'C');
            $pdf->Cell(35, 7, 'Goods Name', 1, 0, 'C');
            $pdf->Cell(24, 7, 'Receiver', 1, 0, 'C');
            $pdf->Cell(48, 7, 'Address', 1, 0, 'C');
            $pdf->Cell(16, 7, 'Qty', 1, 0, 'C');
            $pdf->Cell(25, 7, 'Total', 1, 0, 'C');

            $pdf->Ln();

            $no = 1;
            $grandTotal = 0;
            foreach ($data as $d) {
                $grandTotal += $d['GrandTotal'];
                $pdf->SetFont('Arial', '', 8);
                $pdf->Cell(7, 7, $no++ . '.', 1, 0, 'C');
                $pdf->Cell(16, 7, date('d-m-Y', strtotime($d['DateOutgoing'])), 1, 0, 'C');
                $pdf->Cell(27, 7, $d['IdGoodsOutgoing'], 1, 0, 'C');
                $pdf->Cell(35, 7, $d['NameGoods'], 1, 0, 'L');
                $pdf->Cell(24, 7, $d['NameRecipient'], 1, 0, 'L');
                $pdf->Cell(48, 7, $d['Address'], 1, 0, 'L');
                $pdf->Cell(16, 7, $d['AmountOutgoing'] . ' ' . $d['NameUnit'], 1, 0, 'C');
                $pdf->Cell(25, 7, '$'.number_format($d['GrandTotal'],0,',','.'), 1, 0, 'L');

                $pdf->Ln();
                
            }
                $pdf->Cell(173, 7, 'GRAND TOTAL', 1, 0, 'C');
                $pdf->Cell(25, 7, '$'.number_format($grandTotal,0,',','.'), 1, 0, 'L');
                $pdf->Ln();
        endif;

        $file_name = $table . ' ' . $Date;
        $pdf->Output('I', $file_name);
    }
}
