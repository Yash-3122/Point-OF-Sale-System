<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        check_login();
        if (!is_admin()) {
            redirect('dashboard');
        }

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "User Management";
        $data['users'] = $this->admin->getUsers(userdata('IdUser'));
        $this->template->load('templates/dashboard', 'user/data', $data);
    }

    private function _validation($mode)
    {
        $this->form_validation->set_rules('Name', 'Name', 'required|trim');
        $this->form_validation->set_rules('NoTelp', 'Nomor Telepon', 'required|trim');
        $this->form_validation->set_rules('role', 'Role', 'required|trim');

        if ($mode == 'add') {
            $this->form_validation->set_rules('username', 'Username', 'required|trim|is_unique[user.username]|alpha_numeric');
            $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|is_unique[user.email]');
            $this->form_validation->set_rules('password', 'Password', 'required|min_length[3]|trim');
            $this->form_validation->set_rules('password2', 'Konfirmasi Password', 'matches[password]|trim');
        } else {
            $db = $this->admin->get('user', ['IdUser' => $this->input->post('IdUser', true)]);
            $username = $this->input->post('username', true);
            $email = $this->input->post('email', true);

            $uniq_username = $db['username'] == $username ? '' : '|is_unique[user.username]';
            $uniq_email = $db['email'] == $email ? '' : '|is_unique[user.email]';

            $this->form_validation->set_rules('username', 'Username', 'required|trim|alpha_numeric' . $uniq_username);
            $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email' . $uniq_email);
        }
    }

    public function add()
    {
        $this->_validation('add');

        if ($this->form_validation->run() == false) {
            $data['title'] = "Add User";
            $this->template->load('templates/dashboard', 'user/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $input_data = [
                'Name'          => $input['Name'],
                'username'      => $input['username'],
                'email'         => $input['email'],
                'NoTelp'       => $input['NoTelp'],
                'role'          => $input['role'],
                'password'      => password_hash($input['password'], PASSWORD_DEFAULT),
                'CreatedAt'    => time(),
                'Photo'          => 'user.png'
            ];

            if ($this->admin->insert('user', $input_data)) {
                setMessage('Data Saved');
                redirect('user');
            } else {
                setMessage('Something Went Wrong', false);
                redirect('user/add');
            }
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_validation('edit');

        if ($this->form_validation->run() == false) {
            $data['title'] = "Edit User";
            $data['user'] = $this->admin->get('user', ['IdUser' => $id]);
            $this->template->load('templates/dashboard', 'user/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            $input_data = [
                'Name'          => $input['Name'],
                'username'      => $input['username'],
                'email'         => $input['email'],
                'NoTelp'       => $input['NoTelp'],
                'role'          => $input['role']
            ];

            if ($this->admin->update('user', 'IdUser', $id, $input_data)) {
                setMessage('Data has  been changed');
                redirect('user');
            } else {
                setMessage('Something went wrong', false);
                redirect('user/edit/' . $id);
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('user', 'IdUser', $id)) {
            setMessage('Data Deleted');
        } else {
            setMessage('Something went wrong', false);
        }
        redirect('user');
    }

    public function toggle($getId)
    {
        $id = encode_php_tags($getId);
        $status = $this->admin->get('user', ['IdUser' => $id])['IsActive'];
        $toggle = $status ? 0 : 1; //Jika user aktif maka deactivate, begitu pula sebaliknya
        $Message = $toggle ? 'User Activated' : 'User Deactivated';

        if ($this->admin->update('user', 'IdUser', $id, ['IsActive' => $toggle])) {
            setMessage($Message);
        }
        redirect('user');
    }
}
