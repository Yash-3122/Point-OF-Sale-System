<?php
defined('BASEPATH') or exit('No direct script access allowed');

class tblUnit extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        check_login();

        $this->load->model('Admin_model','admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Goods Unit";
        $data['tblUnit'] = $this->admin->get('tblUnit');
        $this->template->load('templates/dashboard', 'tblUnit/data', $data);
    }

    private function _validation()
    {
        $this->form_validation->set_rules('NameUnit', 'Name tblUnit', 'required|trim');
    }

    public function add()
    {
        $this->_validation();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Goods Unit";
            $this->template->load('templates/dashboard', 'tblUnit/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $insert = $this->admin->insert('tblUnit', $input);
            if ($insert) {
                setMessage('Data Saved');
                redirect('tblUnit');
            } else {
                setMessage('Data Failed To Save', false);
                redirect('tblUnit/add');
            }
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_validation();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Goods Unit";
            $data['tblUnit'] = $this->admin->get('tblUnit', ['IdUnit' => $id]);
            $this->template->load('templates/dashboard', 'tblUnit/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            $update = $this->admin->update('tblUnit', 'IdUnit', $id, $input);
            if ($update) {
                setMessage('Data Saved');
                redirect('tblUnit');
            } else {
                setMessage('Something went wrong', false);
                redirect('tblUnit/add');
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('tblUnit', 'IdUnit', $id)) {
            setMessage('Requested data has been deleted');
        } else {
            setMessage('Something went wrong', false);
        }
        redirect('tblUnit');
    }
}
