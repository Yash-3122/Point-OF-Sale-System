<?php
defined('BASEPATH') or exit('No direct script access allowed');

class tblGoodsOutgoing extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        check_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Out-Going Goods";
        $data['tblGoodsOutgoing'] = $this->admin->gettblGoodsOutgoing();
        $data['IdGoodsOutgoing'] = "";
        $this->template->load('templates/dashboard', 'tblGoodsOutgoing/data', $data);
    }

    private function _validation()
    {
        $this->form_validation->set_rules('NameRecipient', 'Name Penerima', 'required|trim');
        $this->form_validation->set_rules('Address', 'Address', 'required|trim');
        $this->form_validation->set_rules('Discount', 'Discount', "trim|less_than_equal_to[{$this->input->post('TotalNominal')}]");
    }

    private function _validation_cart()
    {   
        $this->form_validation->set_rules('GoodsId', 'tblGoods', 'required');

        $input = $this->input->post('GoodsId', true);
        $Stock = $this->admin->get('tblGoods', ['IdGoods' => $input])['Stock'];
        $Stock_valid = $Stock + 0.1;
       
        $this->form_validation->set_rules(
            'AmountOutgoing',
            'Jumlah Keluar',
            "required|trim|numeric|greater_than[0]|less_than[{$Stock_valid}]",
            [
                'less_than' => "Total Exits cannot be more than {$Stock}"
            ]
        );
    }

    public function add()
    {
        $this->_validation();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Out-Going Goods";
            $data['tblGoods'] = $this->admin->get('tblGoods', null, ['Stock >' => 0]);

            // Mendapatkan dan men-generate kode Transaction tblGoods keluar
            $kode = 'S' . date('ymd');
            $kode_terakhir = $this->admin->getMax('tblGoodsOutgoing', 'IdGoodsOutgoing', $kode);
            $kode_tambah = substr($kode_terakhir, -4, 4);
            $kode_tambah++;
            $number = str_pad($kode_tambah, 4, '0', STR_PAD_LEFT);
            $data['IdGoodsOutgoing'] = $kode . $number;


            $this->template->load('templates/dashboard', 'tblGoodsOutgoing/add', $data);
        } else {
            // $input = $this->input->post(null, true);
            $input = array(
                'IdGoodsOutgoing' => $this->input->post('IdGoodsOutgoing'),
                'UserId' => $this->input->post('UserId'),
                'DateOutgoing' => $this->input->post('DateOutgoing'),
                'NameRecipient' => $this->input->post('NameRecipient'),
                'Address' => $this->input->post('Address'),
                'Discount' => $this->input->post('Discount'),
                'TotalNominal' => $this->input->post('TotalNominal'),
                );
            if ($this->input->post('GrandTotal')=="") {
            $input['GrandTotal'] = $this->input->post('GrandTotal_hidden');
            } else {
            $input['GrandTotal'] = $this->input->post('GrandTotal');
            }
            $insert = $this->admin->insert('tblGoodsOutgoing', $input);

            $IdGoodsOutgoing = $this->input->post('IdGoodsOutgoing');
            $this->admin->simpan_cart($IdGoodsOutgoing);
            $this->cart->destroy();

            // var_dump($input);

            if ($insert) {
                setMessage('Data Saved!');
                redirect('tblGoodsOutgoing');
            } else {
                setMessage('Oops, Something went wrong!');
                redirect('tblGoodsOutgoing/add');
            }
        }
    }

    public function add_to_cart(){
        $this->_validation_cart();
        if ($this->form_validation->run() == false) {
        $data['title'] = "Out-Going Goods";
        $data['tblGoods'] = $this->admin->get('tblGoods', null, ['Stock >' => 0]);

        // Mendapatkan dan men-generate kode Transaction tblGoods keluar
        $kode = 'S-' . date('y');
        $kode_terakhir = $this->admin->getMax('tblGoodsOutgoing', 'IdGoodsOutgoing', $kode);
        $kode_tambah = substr($kode_terakhir, -4, 4);
        $kode_tambah++;
        $number = str_pad($kode_tambah, 4, '0', STR_PAD_LEFT);
        $data['IdGoodsOutgoing'] = $kode . $number;

        $this->template->load('templates/dashboard', 'tblGoodsOutgoing/add', $data);
        } else {
        $GoodsId=$this->input->post('GoodsId');
        $tblGoods=$this->admin->get_tblGoods($GoodsId);
        $i=$tblGoods->row_array();
        $data = array(
           'id'       => $i['IdGoods'],
           'name'     => $i['NameGoods'],
           'price'    => str_replace(",", "", $this->input->post('Price')),
           'qty'      => $this->input->post('AmountOutgoing'),
           'amount'   => str_replace(",", "", $this->input->post('Price'))
        );
        // var_dump($data);
        $this->cart->insert($data);
        redirect('tblGoodsOutgoing/add');
        }
    }

    public function remove(){
        $row_id=$this->uri->segment(3);
        $this->cart->update(array(
               'rowid'      => $row_id,
               'qty'     => 0
            ));
        redirect('tblGoodsOutgoing/add');
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        //Tambah Stock jika hit hapus data
        if ($id) {
        $get = $this->admin->getIDtblGoodsOutgoing2($id)->result_array();
        foreach ($get as $i) {
        $data['Stock'] = $i['AmountOutgoing'] + $i['Stock'];
        $this->admin->update_Stock($i['GoodsId'], $data);
        // var_dump($data);
        }
        }

        if ($this->admin->delete('tblGoodsOutgoing', 'IdGoodsOutgoing', $id)) {
            setMessage('Data Deleted!');
        } else {
            setMessage('Something went wrong', false);
        }
        redirect('tblGoodsOutgoing');
    }

    public function Invoice_Letter($id){
        $x['title'] = "Invoice";
        $x['data'] = $this->admin->getIDtblGoodsOutgoing2($id);
        $this->load->view('Invoice/Letter', $x);
    }

    public function Invoice_Bill($id){
        $x['title'] = "Billing Invoice";
        $x['data'] = $this->admin->getIDtblGoodsOutgoing2($id);
        $this->load->view('Invoice/Bill', $x);
    }

    public function Letter($id){
        $x['title'] = "Invoice";
        $x['data'] = $this->admin->getIDtblGoodsOutgoing($id);
        $this->load->view('Invoice/Letter', $x);
    }
}
