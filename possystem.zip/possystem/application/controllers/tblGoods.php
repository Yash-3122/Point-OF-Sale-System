<?php
defined('BASEPATH') or exit('No direct script access allowed');

class tblGoods extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        check_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Goods";
        $data['tblGoods'] = $this->admin->gettblGoods();
        $this->template->load('templates/dashboard', 'tblGoods/data', $data);
    }

    private function _validation()
    {
        $this->form_validation->set_rules('NameGoods', 'Name tblGoods', 'required|trim');
        $this->form_validation->set_rules('TypeId', 'tblType tblGoods', 'required');
        $this->form_validation->set_rules('UnitId', 'tblUnit tblGoods', 'required');
        $this->form_validation->set_rules('Price', 'Price tblGoods', 'required');
    }

    public function add()
    {
        $this->_validation();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Goods";
            $data['tblType'] = $this->admin->get('tblType');
            $data['tblUnit'] = $this->admin->get('tblUnit');

            // Mengenerate ID tblGoods
            $kode_terakhir = $this->admin->getMax('tblGoods', 'IdGoods');
            $kode_tambah = substr($kode_terakhir, -4, 4);
            $kode_tambah++;
            $number = str_pad($kode_tambah, 4, '0', STR_PAD_LEFT);
            $data['IdGoods'] = 'CA' . $number;

            $this->template->load('templates/dashboard', 'tblGoods/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $insert = $this->admin->insert('tblGoods', $input);

            if ($insert) {
                setMessage('Data saved successfully!');
                redirect('tblGoods');
            } else {
                setMessage('Something went wrong');
                redirect('tblGoods/add');
            }
        }
    }

    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_validation();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Goods";
            $data['tblType'] = $this->admin->get('tblType');
            $data['tblUnit'] = $this->admin->get('tblUnit');
            $data['tblGoods'] = $this->admin->get('tblGoods', ['IdGoods' => $id]);
            $this->template->load('templates/dashboard', 'tblGoods/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            $update = $this->admin->update('tblGoods', 'IdGoods', $id, $input);

            if ($update) {
                setMessage('Data saved successfully!');
                redirect('tblGoods');
            } else {
                setMessage('Something Went Wrong');
                redirect('tblGoods/edit/' . $id);
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('tblGoods', 'IdGoods', $id)) {
            setMessage('Data Deleted!');
        } else {
            setMessage('Something Went Wrong', false);
        }
        redirect('tblGoods');
    }

    public function getStock($getId)
    {
        $id = encode_php_tags($getId);
        $query = $this->admin->checkStock($id);
        output_json($query);
    }
}
