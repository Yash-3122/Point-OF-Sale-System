<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        check_login();

        $this->load->model('Admin_model', 'admin');
    }

    public function index()
    {
        $data['title'] = "Dashboard";
        $data['tblGoods'] = $this->admin->count('tblGoods');
        $data['tblGoodsIncoming'] = $this->admin->count('tblGoodsIncoming');
        $data['tblGoodsOutgoing'] = $this->admin->count('tblGoodsOutgoingDtl');
        $data['tblSupplier'] = $this->admin->count('tblSupplier');
        // $data['user'] = $this->admin->count('user');
        $data['Stock'] = $this->admin->sum('tblGoods', 'Stock');
        $data['earnings'] = $this->admin->sum('tblGoodsOutgoing', 'GrandTotal');
        $data['tblGoods_min'] = $this->admin->min('tblGoods', 'Stock', 10);
        $data['Transaction'] = [
            'tblGoodsIncoming' => $this->admin->gettblGoodsIncoming(5),
            'tblGoodsOutgoing' => $this->admin->gettblGoodsOutgoingDashboard(5)
        ];

        // Line Chart
        $bln = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'];
        $data['cbm'] = [];
        $data['cbk'] = [];

        foreach ($bln as $b) {
            $data['cbm'][] = $this->admin->charttblGoodsIncoming($b);
            $data['cbk'][] = $this->admin->charttblGoodsOutgoing($b);
        }

        $this->template->load('templates/dashboard', 'dashboard', $data);
    }
}
