<?php
defined('BASEPATH') or exit('No direct script access allowed');

class tblSupplier extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        check_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Supplier";
        $data['tblSupplier'] = $this->admin->get('tblSupplier');
        $this->template->load('templates/dashboard', 'tblSupplier/data', $data);
    }

    private function _validation()
    {
        $this->form_validation->set_rules('NameSupplier', 'Name tblSupplier', 'required|trim');
        $this->form_validation->set_rules('NoTelp', 'Nomor Telepon', 'required|trim|numeric');
        $this->form_validation->set_rules('Address', 'Address', 'required|trim');
    }

    public function add()
    {
        $this->_validation();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Supplier";
            $this->template->load('templates/dashboard', 'tblSupplier/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $save = $this->admin->insert('tblSupplier', $input);
            if ($save) {
                setMessage('Data Saved');
                redirect('tblSupplier');
            } else {
                setMessage('Something went wrong', false);
                redirect('tblSupplier/add');
            }
        }
    }


    public function edit($getId)
    {
        $id = encode_php_tags($getId);
        $this->_validation();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Supplier";
            $data['tblSupplier'] = $this->admin->get('tblSupplier', ['IdSupplier' => $id]);
            $this->template->load('templates/dashboard', 'tblSupplier/edit', $data);
        } else {
            $input = $this->input->post(null, true);
            $update = $this->admin->update('tblSupplier', 'IdSupplier', $id, $input);

            if ($update) {
                setMessage('Data Updated');
                redirect('tblSupplier');
            } else {
                setMessage('Something went wrong');
                redirect('tblSupplier/edit/' . $id);
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('tblSupplier', 'IdSupplier', $id)) {
            setMessage('Data Deleted');
        } else {
            setMessage('Something went wrong', false);
        }
        redirect('tblSupplier');
    }
}
