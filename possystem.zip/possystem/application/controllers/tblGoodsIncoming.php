<?php
defined('BASEPATH') or exit('No direct script access allowed');

class tblGoodsIncoming extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        check_login();

        $this->load->model('Admin_model', 'admin');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $data['title'] = "Incoming Goods";
        $data['tblGoodsIncoming'] = $this->admin->gettblGoodsIncoming();
        $this->template->load('templates/dashboard', 'tblGoodsIncoming/data', $data);
    }

    private function _validation()
    {
        $this->form_validation->set_rules('DateIncoming', 'Date Masuk', 'required|trim');
        $this->form_validation->set_rules('tblSupplierId', 'tblSupplier', 'required');
        $this->form_validation->set_rules('GoodsId', 'tblGoods', 'required');
        $this->form_validation->set_rules('AmountIncoming', 'Jumlah Masuk', 'required|trim|numeric|greater_than[0]');
    }

    public function add()
    {
        $this->_validation();
        if ($this->form_validation->run() == false) {
            $data['title'] = "Incoming Goods";
            $data['tblSupplier'] = $this->admin->get('tblSupplier');
            $data['tblGoods'] = $this->admin->get('tblGoods');

            // Mendapatkan dan men-generate kode Transaction tblGoods masuk
            $kode = 'I' . date('ymd');
            $kode_terakhir = $this->admin->getMax('tblGoodsIncoming', 'IdGoodsIncoming', $kode);
            $kode_tambah = substr($kode_terakhir, -4, 4);
            $kode_tambah++;
            $number = str_pad($kode_tambah, 4, '0', STR_PAD_LEFT);
            $data['IdGoodsIncoming'] = $kode . $number;

            $this->template->load('templates/dashboard', 'tblGoodsIncoming/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $insert = $this->admin->insert('tblGoodsIncoming', $input);
            
            // var_dump($input);

            if ($insert) {
                setMessage('Data Saved!');
                redirect('tblGoodsIncoming');
            } else {
                setMessage('Oops, Something went wrong!');
                redirect('tblGoodsIncoming/add');
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('tblGoodsIncoming', 'IdGoodsIncoming', $id)) {
            setMessage('Data Deleted');
        } else {
            setMessage('Something went wrong', false);
        }
        redirect('tblGoodsIncoming');
    }
}
