<?= $this->session->flashdata('Message'); ?>
<div class="card shadow-sm border-bottom-primary">
    <div class="card-header bg-white py-3">
        <div class="row">
            <div class="col">
                <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                Incoming Goods History
                </h4>
            </div>
            <div class="col-auto">
                <a href="<?= base_url('tblGoodsIncoming/add') ?>" class="btn btn-sm btn-primary btn-icon-split">
                    <span class="icon">
                        <i class="fa fa-plus"></i>
                    </span>
                    <span class="text">
                        Add Incoming Goods
                    </span>
                </a>
            </div>
        </div>
    </div>
    <div class="table-responsive">
        <table class="table table-striped table-hover w-100 dt-responsive nowrap" id="dataTable">
            <thead>
                <tr>
                    <th># </th>
                    <th>T- ID</th>
                    <th>Entry Date</th>
                    <th>tblSupplier</th>
                    <th>Good's Name</th>
                    <th>Qty</th>
                    <th>User</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                if ($tblGoodsIncoming) :
                    foreach ($tblGoodsIncoming as $bm) :
                        ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $bm['IdGoodsIncoming']; ?></td>
                            <td><?= $bm['DateIncoming']; ?></td>
                            <td><?= $bm['NameSupplier']; ?></td>
                            <td><?= $bm['NameGoods']; ?></td>
                            <td><?= number_format($bm['AmountIncoming'],1) . ' ' . $bm['NameUnit']; ?></td>
                            <td><?= $bm['Name']; ?></td>
                            <td>
                                <a onclick="return confirm('You sure about it?')" href="<?= base_url('tblGoodsIncoming/delete/') . $bm['IdGoodsIncoming'] ?>" class="btn btn-danger btn-circle btn-sm"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="8" class="text-center">
                            Blank Data
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>