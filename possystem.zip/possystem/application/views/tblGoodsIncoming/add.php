<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm border-bottom-primary">
            <div class="card-header bg-white py-3">
                <div class="row">
                    <div class="col">
                        <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                            Input Incoming Goods Form
                        </h4>
                    </div>
                    <div class="col-auto">
                        <a href="<?= base_url('tblGoodsIncoming') ?>" class="btn btn-sm btn-secondary btn-icon-split">
                            <span class="icon">
                                <i class="fa fa-arrow-left"></i>
                            </span>
                            <span class="text">
                                Back
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?= $this->session->flashdata('Message'); ?>
                <?= form_open('', [], ['IdGoodsIncoming' => $IdGoodsIncoming, 'UserId' => $this->session->userdata('login_session')['user']]); ?>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="IdGoodsIncoming">ID IGT</label>
                    <div class="col-md-4">
                        <input value="<?= $IdGoodsIncoming; ?>" type="text" readonly="readonly" class="form-control">
                        <?= form_error('IdGoodsIncoming', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="DateIncoming">Entry Date</label>
                    <div class="col-md-4">
                        <input value="<?= set_value('DateIncoming', date('Y-m-d')); ?>" name="DateIncoming" id="DateIncoming" type="text" class="form-control date" placeholder="Date Masuk...">
                        <?= form_error('DateIncoming', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="tblSupplierId">Supplier</label>
                    <div class="col-md-5">
                        <div class="input-group">
                            <select name="tblSupplierId" id="tblSupplierId" class="custom-select">
                                <option value="" selected disabled>Select tblSupplier..</option>
                                <?php foreach ($tblSupplier as $s) : ?>
                                    <option <?= set_select('tblSupplierId', $s['IdSupplier']) ?> value="<?= $s['IdSupplier'] ?>"><?= $s['NameSupplier'] ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="input-group-append">
                                <a class="btn btn-primary" href="<?= base_url('tblSupplier/add'); ?>"><i class="fa fa-plus"></i></a>
                            </div>
                        </div>
                        <?= form_error('tblSupplierId', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="GoodsId">Goods</label>
                    <div class="col-md-5">
                        <div class="input-group">
                            <select name="GoodsId" id="GoodsId" class="custom-select">
                                <option value="" selected disabled>Select Goods..</option>
                                <?php foreach ($tblGoods as $b) : ?>
                                    <option <?= $this->uri->segment(3) == $b['IdGoods'] ? 'selected' : '';  ?> <?= set_select('GoodsId', $b['IdGoods']) ?> value="<?= $b['IdGoods'] ?>"><?= $b['IdGoods'] . ' | ' . $b['NameGoods'] ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="input-group-append">
                                <a class="btn btn-primary" href="<?= base_url('tblGoods/add'); ?>"><i class="fa fa-plus"></i></a>
                            </div>
                        </div>
                        <?= form_error('GoodsId', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="Stock">Stock</label>
                    <div class="col-md-5">
                        <input readonly="readonly" id="Stock" type="number" class="form-control">
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="AmountIncoming">Quantity</label>
                    <div class="col-md-5">
                        <div class="input-group">
                            <input value="<?= set_value('AmountIncoming'); ?>" name="AmountIncoming" id="AmountIncoming" type="number" min="0" value="0" step="0.1" class="form-control">
                            <div class="input-group-append">
                                <span class="input-group-text" id="tblUnit">Unit</span>
                            </div>
                        </div>
                        <?= form_error('AmountIncoming', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="total_Stock">Total Stock</label>
                    <div class="col-md-5">
                        <input readonly="readonly" id="total_Stock" type="number" class="form-control">
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col offset-md-4">
                        <button type="submit" class="btn btn-success">Save</button>
                        <button type="reset" class="btn btn-danger">Reset</button>
                    </div>
                </div>
                <?= form_close(); ?>
            </div>
        </div>
    </div>
</div>