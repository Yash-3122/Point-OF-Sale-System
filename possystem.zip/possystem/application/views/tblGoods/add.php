<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm border-bottom-primary">
            <div class="card-header bg-white py-3">
                <div class="row">
                    <div class="col">
                        <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                        Add Goods Form
                        </h4>
                    </div>
                    <div class="col-auto">
                        <a href="<?= base_url('tblGoods') ?>" class="btn btn-sm btn-secondary btn-icon-split">
                            <span class="icon">
                                <i class="fa fa-arrow-left"></i>
                            </span>
                            <span class="text">
                                Back
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?= $this->session->flashdata('Message'); ?>
                <?= form_open('', [], ['Stock' => 0]); ?>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="IdGoods">Goods ID</label>
                    <div class="col-md-9">
                        <input readonly value="<?= set_value('IdGoods', $IdGoods); ?>" name="IdGoods" id="IdGoods" type="text" class="form-control" placeholder="ID...">
                        <?= form_error('IdGoods', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="NameGoods">Goods Name</label>
                    <div class="col-md-9">
                        <input value="<?= set_value('NameGoods'); ?>" name="NameGoods" id="NameGoods" type="text" class="form-control" placeholder="Enter Name">
                        <?= form_error('NameGoods', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="TypeId">Type of Goods</label>
                    <div class="col-md-9">
                        <div class="input-group">
                            <select name="TypeId" id="TypeId" class="custom-select">
                                <option value="" selected disabled>Please Select..</option>
                                <?php foreach ($tblType as $j) : ?>
                                    <option <?= set_select('TypeId', $j['IdType']) ?> value="<?= $j['IdType'] ?>"><?= $j['NameType'] ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="input-group-append">
                                <a class="btn btn-primary" href="<?= base_url('tblType/add'); ?>"><i class="fa fa-plus"></i></a>
                            </div>
                        </div>
                        <?= form_error('TypeId', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="UnitId">Goods Unit</label>
                    <div class="col-md-9">
                        <div class="input-group">
                            <select name="UnitId" id="UnitId" class="custom-select">
                                <option value="" selected disabled>Please Select..</option>
                                <?php foreach ($tblUnit as $s) : ?>
                                    <option <?= set_select('UnitId', $s['IdUnit']) ?> value="<?= $s['IdUnit'] ?>"><?= $s['NameUnit'] ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="input-group-append">
                                <a class="btn btn-primary" href="<?= base_url('tblUnit/add'); ?>"><i class="fa fa-plus"></i></a>
                            </div>
                        </div>
                        <?= form_error('UnitId', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="Price">Price</label>
                    <div class="col-md-9">
                        <div class="input-group">
                        <div class="input-group-append">
                            <span class="input-group-text">$</span>
                        </div>
                        <input value="<?= set_value('Price'); ?>" name="Price" id="Price" type="number" class="form-control" placeholder="Price">
                        </div>
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col-md-9 offset-md-3">
                        <button type="submit" class="btn btn-success">Save</button>
                        <button type="reset" class="btn btn-danger">Reset</bu>
                    </div>
                </div>
                <?= form_close(); ?>
            </div>
        </div>
    </div>
</div>