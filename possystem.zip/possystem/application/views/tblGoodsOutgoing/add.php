<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm border-bottom-primary">
            <div class="card-header bg-white py-3">
                <div class="row">
                    <div class="col">
                        <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                            Enter Multiple Out-Going Goods
                        </h4>
                    </div>
                    <div class="col-auto">
                        <a href="<?= base_url('tblGoodsOutgoing') ?>" class="btn btn-sm btn-secondary btn-icon-split">
                            <span class="icon">
                                <i class="fa fa-arrow-left"></i>
                            </span>
                            <span class="text">
                                Back
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?= $this->session->flashdata('Message'); ?>
                <form action="<?php echo base_url('tblGoodsOutgoing/add_to_cart'); ?>" method="post">
                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="GoodsId">Goods</label>
                    <div class="col-md-5">
                        <div class="input-group">
                            <select name="GoodsId" id="GoodsId" class="custom-select">
                                <option value="" selected disabled>Please Select..</option>
                                <?php foreach ($tblGoods as $b) : ?>
                                    <option value="<?= $b['IdGoods'] ?>"><?= $b['IdGoods'] . ' | ' . $b['NameGoods'] ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="input-group-append">
                                <a class="btn btn-primary" href="<?= base_url('tblGoods/add'); ?>"><i class="fa fa-plus"></i></a>
                            </div>
                        </div>
                        <?= form_error('GoodsId', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="Price">Price</label>
                    <div class="col-md-5">
                        <input readonly="readonly" id="Price" name="Price" type="number" class="form-control">
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="Stock">Stock</label>
                    <div class="col-md-5">
                        <input readonly="readonly" id="Stock" name="Stock" type="number" class="form-control">
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="AmountOutgoing">Out-Going Number</label>
                    <div class="col-md-5">
                        <div class="input-group">
                            <input value="<?= set_value('AmountOutgoing'); ?>" name="AmountOutgoing" id="AmountOutgoing" type="number" min="0" value="0" step="0.1" class="form-control" placeholder="Out-Going Number">
                            <div class="input-group-append">
                                <span class="input-group-text" id="tblUnit">Units</span>
                            </div>
                        </div>
                        <?= form_error('AmountOutgoing', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="total_Stock">Total Stock</label>
                    <div class="col-md-5">
                        <input readonly="readonly" id="total_Stock" type="number" class="form-control">
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="TotalNominal">Total</label>
                    <div class="col-md-5">
                        <div class="input-group">
                        <div class="input-group-append">
                            <span class="input-group-text">$</span>
                        </div>
                        <input readonly="readonly" name="TotalNominal" id="TotalNominal" type="number" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col offset-md-4">
                        <button type="submit" class="btn btn-primary btn-sm btn-icon-split">
                            <span class="icon">
                                <i class="fa fa-arrow-down"></i>
                            </span>
                            <span class="text">
                                Proceed
                            </span>
                        </button>
                    </div>
                </div>
                <table class="table table-hover table-bordered" style="font-size:12px;margin-top:10px;">
                <thead>
                    <tr>
                        <th style="text-align:center;">Goods</th>
                        <th style="text-align:center;">Price</th>
                        <th style="text-align:center;">Quantity</th>
                        <th style="text-align:center;">Sub Total</th>
                        <th style="width:100px;text-align:center;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($this->cart->contents() as $items): ?>
                    <?php echo form_hidden($i.'[rowid]', $items['rowid']); ?>
                    <tr>
                         <td style="text-align:center;"><?=$items['id'];?> | <?=$items['name'];?></td>
                         <td style="text-align:center;"><?php echo '$'.number_format($items['amount']);?></td>
                         <td style="text-align:center;"><?php echo number_format($items['qty'],1);?></td>
                         <td style="text-align:center;"><?php echo '$'.number_format($items['subtotal']);?></td>
                        
                         <td style="text-align:center;"><a href="<?php echo base_url().'tblGoodsOutgoing/remove/'.$items['rowid'];?>" class="btn btn-danger btn-sm"> Cancel</a></td>
                    </tr>
                    
                    <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
                </table>
                </form>
            </div>

            <div class="card-header bg-white py-3">
                <div class="row">
                    <div class="col">
                        <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                            Out-Going Goods Form - Additional Details
                        </h4>
                    </div>
                    <div class="col-auto">
                    </div>
                </div>
            </div>
            <div class="card-body">
            <!-- <?= form_open('', [], ['IdGoodsOutgoing' => $IdGoodsOutgoing, 'UserId' => $this->session->userdata('login_session')['user']]); ?> -->
            <form action="<?php echo base_url('tblGoodsOutgoing/add'); ?>" method="post">
            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
            <input type="hidden" name="IdGoodsOutgoing" value="<?php echo $IdGoodsOutgoing; ?>">
            <input type="hidden" name="UserId" value="<?php echo $this->session->userdata('login_session')['user']; ?>">
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="IdGoodsOutgoing">ID OGT</label>
                    <div class="col-md-4">
                        <input value="<?= $IdGoodsOutgoing; ?>" type="text" readonly="readonly" class="form-control">
                        <?= form_error('IdGoodsOutgoing', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="DateOutgoing">Out-Date</label>
                    <div class="col-md-4">
                        <input value="<?= set_value('DateOutgoing', date('Y-m-d')); ?>" name="DateOutgoing" id="DateOutgoing" type="text" class="form-control date" placeholder="Date Keluar...">
                        <?= form_error('DateOutgoing', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="NameRecipient">Name</label>
                    <div class="col-md-5">
                        <input id="NameRecipient" name="NameRecipient" type="text" class="form-control">
                        <?= form_error('NameRecipient', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>

                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="Address">Address</label>
                    <div class="col-md-5">
                        <input id="Address" name="Address" type="text" class="form-control">
                        <?= form_error('Address', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>

                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="Discount">Discount</label>
                    <div class="col-md-5">
                        <div class="input-group">
                            <div class="input-group-append">
                                <span class="input-group-text">$</span>
                            </div>
                            <input name="Discount" id="Discount" type="number" class="form-control" min="1" max="999999999" maxlength="9" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);">
                            <?= form_error('Discount', '<small class="text-danger">', '</small>'); ?>
                        </div>
                    </div>
                </div>

                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="TotalNominal">Total</label>
                    <div class="col-md-5">
                        <div class="input-group">
                            <div class="input-group-append">
                                <span class="input-group-text">$</span>
                            </div>
                            <input readonly="readonly" name="TotalNominal" id="TotalNominal_cart" value="<?php echo $this->cart->total();?>" type="number" class="form-control">
                        </div>
                    </div>
                </div>

                <div class="row form-group">
                    <label class="col-md-4 text-md-right" for="GrandTotal">Total (After Discount)</label>
                    <div class="col-md-5">
                        <div class="input-group">
                        <div class="input-group-append">
                            <span class="input-group-text">$</span>
                        </div>
                        <input readonly="readonly" name="GrandTotal" id="GrandTotal" placeholder="<?php echo $this->cart->total();?>" type="number" class="form-control">
                        <input name="GrandTotal_hidden" value="<?php echo $this->cart->total();?>" type="hidden" class="form-control">
                        </div>
                    </div>

                </div>

                 
                <div class="row form-group">
                    <div class="col offset-md-4">
                        <button type="submit" class="btn btn-success">Save</button>
                        <button type="reset" class="btn btn-danger">Reset</button>
                    </div>
                </div>
                </form>
                <!-- <?= form_close(); ?> -->
            </div>

        </div>
    </div>
</div>

<!-- Menghilangkan panah di form type number -->
<style type="text/css">
/* Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}
/* Firefox */
input[type=number] {
  -moz-appearance: textfield;
}
</style>