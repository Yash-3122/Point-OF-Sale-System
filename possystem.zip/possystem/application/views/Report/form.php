<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card shadow-sm border-bottom-primary">
            <div class="card-header bg-white py-3">
                <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                    Report Form
                </h4>
            </div>
            <div class="card-body">
                <?= $this->session->flashdata('Message'); ?>
                <?= form_open(); ?>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="Transaction">Transaction Report</label>
                    <div class="col-md-9">
                        <div class="custom-control custom-radio">
                            <input value="tblGoodsIncoming" type="radio" id="tblGoodsIncoming" name="Transaction" class="custom-control-input">
                            <label class="custom-control-label" for="tblGoodsIncoming">Incoming Goods</label>
                        </div>
                        <div class="custom-control custom-radio">
                            <input value="tblGoodsOutgoing" type="radio" id="tblGoodsOutgoing" name="Transaction" class="custom-control-input">
                            <label class="custom-control-label" for="tblGoodsOutgoing">Out-Going Goods</label>
                        </div>
                        <div class="custom-control custom-radio">
                            <input value="tblGoodsOutgoing_nominal" type="radio" id="tblGoodsOutgoing_nominal" name="Transaction" class="custom-control-input">
                            <label class="custom-control-label" for="tblGoodsOutgoing_nominal">Out-Going Goods + Total Amount</label>
                        </div>
                        <?= form_error('Transaction', '<span class="text-danger small">', '</span>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <label class="col-lg-3 text-lg-right" for="Date">Date</label>
                    <div class="col-lg-5">
                        <div class="input-group">
                            <input value="<?= set_value('Date'); ?>" name="Date" id="Date" type="text" class="form-control" placeholder="Periode Date">
                            <div class="input-group-append">
                                <span class="input-group-text"><i class="fa fa-fw fa-calendar"></i></span>
                            </div>
                        </div>
                        <?= form_error('Date', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col-lg-9 offset-lg-3">
                        <button type="submit" class="btn btn-primary btn-icon-split">
                            <span class="icon">
                                <i class="fa fa-print"></i>
                            </span>
                            <span class="text">
                                Fetch & Download
                            </span>
                        </button>
                    </div>
                </div>
                <?= form_close(); ?>
            </div>
        </div>
    </div>
</div>